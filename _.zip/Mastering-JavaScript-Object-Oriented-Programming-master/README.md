## $5 Tech Unlocked 2021!
[Buy and download this Book for only $5 on PacktPub.com](https://www.packtpub.com/product/mastering-javascript-object-oriented-programming/9781785889103)
-----
*If you have read this book, please leave a review on [Amazon.com](https://www.amazon.com/gp/product/1785889109).     Potential readers can then use your unbiased opinion to help them make purchase decisions. Thank you. The $5 campaign         runs from __December 15th 2020__ to __January 13th 2021.__*

# Mastering-JavaScript-Object-Oriented-Programming
[Mastering JavaScript Object-Oriented Programming](https://www.packtpub.com/web-development/mastering-javascript-object-oriented-programming?utm_source=GitHub&utm_medium=repository&utm_campaign=9781785889103) by [Packt Publishing](https://www.packtpub.com/)


Most of the code provided in this book is not bound to a specific JavaScript runtime environment, so it could run in any JavaScript environment. However some examples are specific for the Web browser environment, so the console of Web Inspector such as Chrome Developer tools or Firebug is needed.

Chapter 1 has no codes.

For more information refer to the following books:
* [Object-Oriented JavaScript](https://www.packtpub.com/web-development/object-oriented-javascript?utm_source=GitHub&utm_medium=repository&utm_campaign=9781847194145)
* [Mastering JavaScript Design Patterns](https://www.packtpub.com/application-development/mastering-javascript-design-patterns?utm_source=GitHub&utm_medium=repository&utm_campaign=9781783987986)
* [Learning Object-Oriented Programming](https://www.packtpub.com/application-development/learning-object-oriented-programming?utm_source=GitHub&utm_medium=repository&utm_campaign=9781785289637)
